# C-DQC v4.1.1

Corrective release for deterministic reuse-readiness verdict assignment.

- A configuration can add purpose-specific required tools but can no longer remove the baseline evidence contract.
- Completeness and metadata checks are always mandatory for a reuse-readiness verdict.
- Privacy-documentation evidence is mandatory when `privacy_required` is true.
- A run that executes only `check_explicit_missingness` now returns `INSUFFICIENT_EVIDENCE`.
- Confirmed or supported quality findings prevent an unconditional `READY` verdict after the minimum checks are completed.
