from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import sys

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from cdqc_core.pipeline import run_assessment


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run one bounded C-DQC agentic integration test.")
    parser.add_argument("--provider", choices=["deterministic", "openai"], default="deterministic")
    parser.add_argument("--model", default="gpt-5.5")
    parser.add_argument("--output", type=Path, default=Path("results/one_agentic_test"))
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.output.exists():
        shutil.rmtree(args.output)
    args.output.mkdir(parents=True)

    input_path = args.output / "test_input.csv"
    config_path = args.output / "test_config.json"
    pd.DataFrame(
        {
            "Measurement": [10.0, None, 12.0, 13.0],
            "Group": ["A", "A", "B", "B"],
            "Outcome": [0, 1, 0, 1],
        }
    ).to_csv(input_path, index=False)

    config = {
        "dataset_id": "one_agentic_integration_test",
        "dataset_metadata": {
            "title": "Synthetic agentic integration test",
            "description": "Small non-clinical tabular test dataset",
            "provenance": "Generated locally by the test script",
            "version": "1.0",
            "license": "CC0-1.0",
            "intended_reuse": "software integration testing",
            "privacy_status": "contains no personal data",
        },
        "dataset_metadata_required_fields": [
            "title", "description", "provenance", "version", "license", "intended_reuse", "privacy_status"
        ],
        "metadata_required_fields": ["role", "description"],
        "reuse_purpose": {
            "task": "binary_machine_learning",
            "target_column": "Outcome",
            "privacy_required": True,
            "required_tools": ["check_explicit_missingness", "check_metadata_completeness", "check_privacy_documentation"],
        },
        "agentic": {
            "enabled": True,
            "provider": args.provider,
            "model": args.model,
            "api_key_env": "OPENAI_API_KEY",
            "max_steps": 1,
            "required_tools": ["check_explicit_missingness"] if args.provider == "deterministic" else [],
            "on_policy_error": "fallback",
        },
        "columns": {
            "Measurement": {"role": "numeric", "description": "Synthetic numeric measurement"},
            "Group": {"role": "categorical", "description": "Synthetic group", "allowed_values": ["A", "B"]},
            "Outcome": {"role": "categorical", "description": "Synthetic binary target", "allowed_values": [0, 1]},
        },
    }
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    run_assessment(input_path, args.output / "assessment", config_path=config_path)

    summary = json.loads((args.output / "assessment" / "agent_summary.json").read_text(encoding="utf-8"))
    trace = json.loads((args.output / "assessment" / "agent_trace.json").read_text(encoding="utf-8"))
    issues = json.loads((args.output / "assessment" / "issues.json").read_text(encoding="utf-8"))
    assert summary["step_count"] == 1, summary
    assert len([entry for entry in trace if entry.get("next_tool")]) == 1, trace
    assert (args.output / "assessment" / "input_snapshot.csv").exists()
    print(json.dumps({
        "status": "PASS",
        "provider": args.provider,
        "executed_tools": summary["executed_tools"],
        "issue_count": len(issues),
        "verdict": summary["verdict"],
        "output": str(args.output / "assessment"),
    }, indent=2))


if __name__ == "__main__":
    main()
