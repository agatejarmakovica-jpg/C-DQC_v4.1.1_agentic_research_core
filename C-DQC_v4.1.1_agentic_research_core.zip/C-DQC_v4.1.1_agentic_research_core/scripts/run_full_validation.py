from __future__ import annotations

import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results" / "validation_run"
if RESULTS.exists():
    shutil.rmtree(RESULTS)
RESULTS.mkdir(parents=True)

pytest_result = subprocess.run([sys.executable, "-m", "pytest", "-q"], cwd=ROOT, text=True, capture_output=True)
print(pytest_result.stdout)
if pytest_result.returncode:
    print(pytest_result.stderr)
    raise SystemExit(pytest_result.returncode)

benchmark_result = subprocess.run(
    [sys.executable, "-m", "cdqc_core", "benchmark", "--output", str(RESULTS / "benchmark"), "--runs", "30", "--rows", "600"],
    cwd=ROOT,
    text=True,
    capture_output=True,
)
print(benchmark_result.stdout)
if benchmark_result.returncode:
    print(benchmark_result.stderr)
    raise SystemExit(benchmark_result.returncode)

report = {
    "tests_passed": True,
    "pytest_stdout": pytest_result.stdout.strip(),
    "benchmark_completed": True,
    "benchmark_report": str((RESULTS / "benchmark" / "benchmark_report.json").relative_to(ROOT)),
}
(RESULTS / "validation_summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
print(json.dumps(report, indent=2))
