# C-DQC v4.1 Agentic Research Core

C-DQC v4.1 adds a bounded LLM policy and a LangGraph execution loop to the auditable v4.0 tabular data-quality core. The design keeps evidence generation deterministic:

1. an aggregate-only dataset profile is created;
2. the policy selects one next detector from a closed catalogue;
3. the selected deterministic detector produces typed evidence;
4. the policy may replan or stop within a fixed step budget;
5. a deterministic rule layer assigns the reuse-readiness verdict;
6. the source dataset is never repaired or mutated.

Health-themed datasets are representative data-science benchmarks. The package is not a clinical decision system and does not make clinical-validity claims.

## Agentic claim boundary

The LLM may select detector tools, target columns, and the stopping point. It may not inspect row-level records, create new detectors, modify values, convert candidates into confirmed errors, authorize repairs, or override the deterministic verdict.

The API receives column names, data types, aggregate statistics, documentation status, reuse purpose, executed-tool history, and issue counts. It does not receive source rows or direct cell values.

## Detector catalogue

- `check_explicit_missingness`
- `check_missing_tokens`
- `check_disguised_missingness`
- `check_range_violations`
- `check_numeric_extremes`
- `check_categorical_consistency`
- `check_date_consistency`
- `check_format_consistency`
- `check_duplicates`
- `check_metadata_completeness`
- `check_privacy_documentation`

Each detector can be invoked independently. The agentic path therefore executes only the selected checks rather than running the fixed pipeline and filtering its outputs afterward.

## Installation

```bash
python -m pip install -r requirements.txt
```

## Run one local integration test

This test uses the deterministic policy, executes exactly one selected detector, and requires no API key:

```bash
python scripts/run_one_agentic_test.py --provider deterministic
```

Expected result:

```json
{
  "status": "PASS",
  "executed_tools": ["check_explicit_missingness"],
  "issue_count": 1
}
```

## Run one OpenAI-policy test

Set the API key in the environment. Do not write it into JSON or Python files.

Linux/macOS:

```bash
export OPENAI_API_KEY="your-key"
python scripts/run_one_agentic_test.py --provider openai --model gpt-5.5
```

Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="your-key"
python scripts/run_one_agentic_test.py --provider openai --model gpt-5.5
```

The test has `max_steps: 1`, so the LLM can select only one detector. If the API call fails and `on_policy_error` is set to `fallback`, the local deterministic policy completes the run and the trace records `fallback_used: true` and the error reason.

## Assess a dataset in fixed-pipeline mode

```bash
python -m cdqc_core assess \
  --input data/diabetes.csv \
  --config configs/diabetes_no_reference.json \
  --output results/diabetes_fixed
```

## Assess a dataset in agentic mode

Copy `configs/agentic_config_template.json`, complete the metadata and reuse-purpose fields, and run:

```bash
python -m cdqc_core assess \
  --input data/diabetes.csv \
  --config configs/my_agentic_config.json \
  --output results/diabetes_agentic
```

The relevant configuration block is:

```json
{
  "reuse_purpose": {
    "task": "binary_machine_learning",
    "target_column": "Outcome",
    "privacy_required": true,
    "required_tools": [
      "check_explicit_missingness",
      "check_metadata_completeness",
      "check_privacy_documentation"
    ]
  },
  "agentic": {
    "enabled": true,
    "provider": "openai",
    "model": "gpt-5.5",
    "api_key_env": "OPENAI_API_KEY",
    "max_steps": 8,
    "required_tools": [],
    "on_policy_error": "fallback"
  }
}
```

## Outputs

Every run preserves the existing v4.0 outputs. Agentic runs additionally write:

- `dataset_profile.json` — aggregate-only policy input;
- `agent_trace.json` — all policy decisions, model, fallback, usage, reasons, and detector results;
- `agent_decisions.csv` — tabular decision trace;
- `tool_execution_log.csv` — executed tools and target columns;
- `agent_summary.json` — graph, step count, stop reason, and verdict;
- `reuse_readiness_verdict.json` — deterministic verdict and its evidence contract.

The source snapshot retains the original schema. Audit information remains in separate files.

## Validation

```bash
python -m pytest -q
```

Validated result for this release:

```text
13 passed
```

The deterministic one-step agentic integration test also passed. The OpenAI transport path is implemented according to the Responses API structured-output pattern, but a paid live API call is not included in the packaged validation because no user API credential is stored or used during release testing.
