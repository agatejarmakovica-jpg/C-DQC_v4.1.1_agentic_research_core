# C-DQC v4.1 lietošana

## 1. Instalēšana

```bash
python -m pip install -r requirements.txt
```

## 2. Viens tests bez API atslēgas

Šis tests pārbauda visu LangGraph izpildes ķēdi un izpilda tieši vienu detektoru:

```bash
python scripts/run_one_agentic_test.py --provider deterministic
```

Sagaidāmais rezultāts ir `PASS`, viena izpildīta pārbaude `check_explicit_missingness` un viena atrasta trūkstoša vērtība.

## 3. Viens tests ar OpenAI API

API atslēgu glabā tikai vides mainīgajā.

Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="jūsu-api-atslēga"
python scripts/run_one_agentic_test.py --provider openai --model gpt-5.5
```

Linux/macOS:

```bash
export OPENAI_API_KEY="jūsu-api-atslēga"
python scripts/run_one_agentic_test.py --provider openai --model gpt-5.5
```

Testa konfigurācijā `max_steps` ir 1, tādēļ LLM izvēlas ne vairāk kā vienu pārbaudi. Ja API nav pieejams un konfigurācijā ir `on_policy_error: fallback`, izpildi pabeidz lokālā deterministiskā politika. Audita failā tiek saglabāts, ka izmantots fallback, un kļūdas iemesls.

## 4. Aģentiskā režīma konfigurācija

Par pamatu izmanto `configs/agentic_config_template.json`.

Svarīgākie lauki:

- `reuse_purpose` definē konkrēto atkārtotas izmantošanas uzdevumu un obligātos pierādījumus;
- `agentic.provider` ir `openai` reālam LLM eksperimentam vai `deterministic` lokālam testam un ablation salīdzinājumam;
- `agentic.model` norāda API modeli;
- `agentic.max_steps` ierobežo aģenta rīku izsaukumu skaitu;
- `agentic.on_policy_error` nosaka, vai API kļūmes gadījumā izmantot drošu fallback.

## 5. Datu minimizācija

LLM netiek sūtītas datu rindas vai šūnu vērtības. Politika saņem tikai agregētu profilu: kolonnu nosaukumus, tipus, trūkstošo vērtību proporcijas, skaitliskos kopsavilkumus, metadatu statusu, atkārtotas izmantošanas mērķi un iepriekš izpildīto pārbaužu kopsavilkumu.

## 6. Rezultāti

Aģentiskā izpilde papildus saglabā:

- `agent_trace.json`;
- `agent_decisions.csv`;
- `tool_execution_log.csv`;
- `agent_summary.json`;
- `reuse_readiness_verdict.json`;
- `dataset_profile.json`.

LLM tikai izvēlas nākamo deterministisko rīku. Tas nelabo datus un nepieņem gala reuse-readiness verdiktu.
