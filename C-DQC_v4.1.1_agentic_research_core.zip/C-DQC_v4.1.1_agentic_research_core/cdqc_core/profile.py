from __future__ import annotations

from typing import Any

import pandas as pd

from .detectors import infer_role


def build_dataset_profile(df: pd.DataFrame, config: dict[str, Any] | None = None) -> dict[str, Any]:
    """Build an aggregate-only profile suitable for an external policy model.

    The profile intentionally excludes row-level records and direct identifiers. It contains
    schema, aggregate statistics, and documentation status only.
    """
    config = config or {}
    column_cfg = config.get("columns", {}) or {}
    required_fields = list(config.get("metadata_required_fields", ["role", "description"]))

    columns: list[dict[str, Any]] = []
    for column in df.columns:
        series = df[column]
        meta = column_cfg.get(column, {}) or {}
        observed = series.dropna()
        role = str(meta.get("role") or infer_role(str(column), series)).casefold()
        item: dict[str, Any] = {
            "name": str(column),
            "dtype": str(series.dtype),
            "inferred_or_declared_role": role,
            "row_count": int(len(series)),
            "observed_count": int(series.notna().sum()),
            "missing_count": int(series.isna().sum()),
            "missing_rate": float(series.isna().mean()) if len(series) else 0.0,
            "unique_count": int(observed.nunique(dropna=True)),
            "metadata_fields_present": sorted(
                field for field in required_fields if meta.get(field) not in (None, "", [], {})
            ),
            "metadata_fields_missing": sorted(
                field for field in required_fields if meta.get(field) in (None, "", [], {})
            ),
            "has_valid_range": meta.get("valid_range") is not None,
            "has_allowed_values": bool(meta.get("allowed_values")),
            "has_target_format": bool(meta.get("target_format")),
            "has_regex": bool(meta.get("regex")),
            "has_declared_sentinels": bool(meta.get("sentinel_values")),
        }
        if pd.api.types.is_numeric_dtype(series) and len(observed):
            numeric = pd.to_numeric(observed, errors="coerce").dropna()
            if len(numeric):
                item["numeric_summary"] = {
                    "minimum": float(numeric.min()),
                    "maximum": float(numeric.max()),
                    "median": float(numeric.median()),
                    "q1": float(numeric.quantile(0.25)),
                    "q3": float(numeric.quantile(0.75)),
                }
        elif len(observed):
            counts = observed.astype("string").value_counts(dropna=True).head(5)
            item["top_value_frequencies"] = [
                {"count": int(count), "share": float(count / len(observed))}
                for count in counts.tolist()
            ]
        columns.append(item)

    dataset_metadata = config.get("dataset_metadata", {}) or {}
    dataset_required = list(
        config.get(
            "dataset_metadata_required_fields",
            ["title", "description", "provenance", "version", "license", "intended_reuse", "privacy_status"],
        )
    )
    return {
        "dataset_id": config.get("dataset_id"),
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "columns": columns,
        "dataset_metadata_fields_present": sorted(
            field for field in dataset_required if dataset_metadata.get(field) not in (None, "", [], {})
        ),
        "dataset_metadata_fields_missing": sorted(
            field for field in dataset_required if dataset_metadata.get(field) in (None, "", [], {})
        ),
        "reuse_purpose": config.get("reuse_purpose", {}),
        "data_minimization": {
            "row_level_records_sent_to_policy": False,
            "direct_values_sent_to_policy": False,
            "aggregate_profile_only": True,
        },
    }
