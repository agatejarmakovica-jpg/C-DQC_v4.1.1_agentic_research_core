from __future__ import annotations

from typing import Any, Iterable

from .models import Issue


BASELINE_REUSE_TOOLS: tuple[str, ...] = (
    "check_explicit_missingness",
    "check_metadata_completeness",
)
PRIVACY_REUSE_TOOL = "check_privacy_documentation"


def _ordered_unique(values: Iterable[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        item = str(value)
        if item and item not in seen:
            seen.add(item)
            result.append(item)
    return result


def determine_reuse_verdict(
    issues: list[Issue],
    executed_tools: list[str],
    config: dict[str, Any],
) -> dict[str, Any]:
    """Assign a deterministic reuse-readiness verdict.

    The configuration may add purpose-specific checks, but it cannot weaken the
    minimum evidence contract. Completeness and metadata evidence are always
    required. Privacy documentation is also mandatory when privacy evidence is
    required for the stated reuse purpose.
    """

    reuse = config.get("reuse_purpose", {}) or {}
    agentic = config.get("agentic", {}) or {}
    privacy_required = bool(reuse.get("privacy_required", True))

    minimum_required = list(BASELINE_REUSE_TOOLS)
    if privacy_required:
        minimum_required.append(PRIVACY_REUSE_TOOL)

    configured_required = _ordered_unique(reuse.get("required_tools", []) or [])
    protocol_required = _ordered_unique(agentic.get("required_tools", []) or [])
    required_tools = _ordered_unique(
        [*minimum_required, *configured_required, *protocol_required]
    )

    missing_required = [
        tool for tool in required_tools if tool not in set(executed_tools)
    ]
    privacy_gap = any(
        issue.issue_type == "privacy_documentation_gap" for issue in issues
    )
    metadata_gaps = [
        issue
        for issue in issues
        if issue.issue_type in {"schema_metadata_gap", "dataset_metadata_gap"}
    ]
    high_severity_confirmed = [
        issue
        for issue in issues
        if issue.evidence_status == "confirmed" and issue.severity >= 0.8
    ]
    confirmed_quality_issues = [
        issue
        for issue in issues
        if issue.evidence_status == "confirmed"
        and issue.issue_type
        not in {
            "schema_metadata_gap",
            "dataset_metadata_gap",
            "privacy_documentation_gap",
        }
    ]
    supported_quality_issues = [
        issue for issue in issues if issue.evidence_status == "supported"
    ]
    unresolved_candidates = [
        issue for issue in issues if issue.evidence_status == "candidate"
    ]

    if missing_required:
        verdict = "INSUFFICIENT_EVIDENCE"
        rationale = (
            "The minimum reuse-readiness evidence contract is incomplete; "
            "one or more mandatory checks were not executed."
        )
    elif privacy_gap and privacy_required:
        verdict = "NOT_READY"
        rationale = (
            "Privacy status is undocumented for a reuse purpose that requires "
            "privacy evidence."
        )
    elif (
        high_severity_confirmed
        or metadata_gaps
        or confirmed_quality_issues
        or supported_quality_issues
        or unresolved_candidates
    ):
        verdict = "CONDITIONALLY_READY"
        rationale = (
            "The minimum evidence contract was completed, but documented data-quality, "
            "metadata, or candidate findings require resolution, acceptance, or "
            "purpose-specific mitigation before reuse."
        )
    else:
        verdict = "READY"
        rationale = (
            "All mandatory checks were executed and no unresolved blocking or "
            "conditional evidence was produced."
        )

    return {
        "verdict": verdict,
        "rationale": rationale,
        "reuse_purpose": reuse,
        "minimum_required_tools": minimum_required,
        "configured_required_tools": configured_required,
        "protocol_required_tools": protocol_required,
        "required_tools": required_tools,
        "executed_tools": executed_tools,
        "missing_required_tools": missing_required,
        "privacy_documentation_gap": privacy_gap,
        "metadata_gap_count": len(metadata_gaps),
        "high_severity_confirmed_count": len(high_severity_confirmed),
        "confirmed_quality_issue_count": len(confirmed_quality_issues),
        "supported_quality_issue_count": len(supported_quality_issues),
        "candidate_issue_count": len(unresolved_candidates),
        "decision_contract": {
            "llm_selects_tools_only": True,
            "deterministic_tools_generate_evidence": True,
            "deterministic_rule_layer_assigns_verdict": True,
            "configuration_cannot_weaken_minimum_evidence": True,
            "llm_cannot_modify_data_or_override_findings": True,
        },
    }
