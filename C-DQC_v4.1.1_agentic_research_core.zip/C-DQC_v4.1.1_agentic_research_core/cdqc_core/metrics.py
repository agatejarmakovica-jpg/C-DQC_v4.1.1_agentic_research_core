from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Iterable

import numpy as np
import pandas as pd

from .models import Issue
from .utils import f1_score


def quality_support_metrics(
    df: pd.DataFrame,
    issues: list[Issue],
    config: dict[str, Any],
    executed_tools: list[str] | None = None,
) -> dict[str, Any]:
    total_cells = int(df.size)
    total_rows = int(len(df))
    explicit_missing = sum(1 for issue in issues if issue.issue_type == "explicit_missingness")
    confirmed_cell_violations = sum(
        1 for issue in issues if issue.scope == "cell" and issue.evidence_status == "confirmed" and issue.issue_type != "explicit_missingness"
    )
    candidate_cell_issues = sum(
        1 for issue in issues if issue.scope == "cell" and issue.evidence_status == "candidate"
    )
    duplicate_rows = sum(1 for issue in issues if issue.issue_type == "exact_duplicate_row")
    columns = list(df.columns)
    column_cfg = config.get("columns", {}) or {}
    required_column_fields = list(config.get("metadata_required_fields", []))
    schema_gap_columns = {
        str(column)
        for column in columns
        if required_column_fields
        and any((column_cfg.get(column, {}) or {}).get(field) in (None, "", [], {}) for field in required_column_fields)
    }
    column_metadata_completeness = 1.0 - len(schema_gap_columns) / max(1, len(columns))
    dataset_metadata = config.get("dataset_metadata", {}) or {}
    dataset_required_fields = list(config.get("dataset_metadata_required_fields", [
        "title", "description", "provenance", "version", "license", "intended_reuse", "privacy_status"
    ]))
    present_dataset_fields = sum(
        dataset_metadata.get(field) not in (None, "", [], {}) for field in dataset_required_fields
    )
    dataset_metadata_completeness = present_dataset_fields / max(1, len(dataset_required_fields))
    metadata_completeness = float(np.mean([column_metadata_completeness, dataset_metadata_completeness]))
    privacy_documentation_support = 1.0 if dataset_metadata.get("privacy_status") not in (None, "") else 0.0
    fixed_pipeline = executed_tools is None
    executed_set = set(executed_tools or [])
    explicit_completeness = (
        1.0 - explicit_missing / max(1, total_cells)
        if fixed_pipeline or "check_explicit_missingness" in executed_set
        else None
    )
    validity_tools = {
        "check_missing_tokens", "check_disguised_missingness", "check_range_violations",
        "check_numeric_extremes", "check_categorical_consistency", "check_date_consistency",
        "check_format_consistency",
    }
    validity_assessed = fixed_pipeline or bool(validity_tools & executed_set)
    confirmed_validity_support = (
        1.0 - confirmed_cell_violations / max(1, total_cells - explicit_missing)
        if validity_assessed else None
    )
    suspected_issue_burden = (
        candidate_cell_issues / max(1, total_cells)
        if validity_assessed else None
    )
    duplicate_free_rate = (
        1.0 - duplicate_rows / max(1, total_rows)
        if fixed_pipeline or "check_duplicates" in executed_set
        else None
    )
    machine_readability = 1.0
    reuse_components = [metadata_completeness, machine_readability, privacy_documentation_support]
    if duplicate_free_rate is not None:
        reuse_components.append(duplicate_free_rate)
    reuse_readiness_support = (
        float(np.mean(reuse_components))
        if fixed_pipeline or duplicate_free_rate is not None
        else None
    )
    assessment_coverage = {
        "mode": "fixed_pipeline" if fixed_pipeline else "agentic_selected_tools",
        "executed_tools": sorted(executed_set) if not fixed_pipeline else "all_fixed_checks",
        "explicit_completeness_assessed": explicit_completeness is not None,
        "duplicate_freedom_assessed": duplicate_free_rate is not None,
        "validity_support_assessed": validity_assessed,
        "support_scores_are_conditional_on_executed_checks": not fixed_pipeline,
    }
    by_type = Counter(issue.issue_type for issue in issues)
    by_status = Counter(issue.evidence_status for issue in issues)
    by_scope = Counter(issue.scope for issue in issues)
    return {
        "metric_contract": {
            "explicit_completeness": "Observed non-null cell proportion.",
            "confirmed_validity_support": "Support score from confirmed metadata-backed cell violations; not ground-truth accuracy.",
            "suspected_issue_burden": "Candidate cell issues requiring confirmation; not confirmed errors.",
            "reuse_readiness_support": "Support score from metadata completeness, duplicate freedom, privacy documentation, and machine readability; null when required support components were not assessed.",
        },
        "shape": {"rows": total_rows, "columns": len(columns), "cells": total_cells},
        "assessment_coverage": assessment_coverage,
        "explicit_missing_cells": explicit_missing,
        "explicit_completeness": explicit_completeness,
        "confirmed_cell_violations": confirmed_cell_violations,
        "confirmed_validity_support": confirmed_validity_support,
        "candidate_cell_issues": candidate_cell_issues,
        "suspected_issue_burden": suspected_issue_burden,
        "duplicate_rows": duplicate_rows,
        "duplicate_free_rate": duplicate_free_rate,
        "schema_gap_columns": len(schema_gap_columns),
        "column_metadata_completeness": column_metadata_completeness,
        "dataset_metadata_completeness": dataset_metadata_completeness,
        "metadata_completeness": metadata_completeness,
        "privacy_documentation_support": privacy_documentation_support,
        "machine_readability": machine_readability,
        "reuse_readiness_support": reuse_readiness_support,
        "issue_counts_by_type": dict(sorted(by_type.items())),
        "issue_counts_by_status": dict(sorted(by_status.items())),
        "issue_counts_by_scope": dict(sorted(by_scope.items())),
    }


def truth_key(record: dict[str, Any]) -> str:
    scope = str(record.get("scope"))
    row = record.get("row_index")
    column = record.get("column")
    if pd.isna(column):
        column = None
    issue_type = str(record.get("issue_type"))
    if pd.isna(row):
        row = None
    elif isinstance(row, (float, np.floating)) and float(row).is_integer():
        row = int(row)
    return f"{scope}|{row}|{column}|{issue_type}"


def issue_truth_key(issue: Issue) -> str:
    return f"{issue.scope}|{issue.row_index}|{issue.column}|{issue.issue_type}"


def detection_metrics(issues: Iterable[Issue], truth_records: list[dict[str, Any]]) -> dict[str, Any]:
    predicted = {issue_truth_key(issue) for issue in issues if issue.scope in {"cell", "row", "column"}}
    truth = {truth_key(record) for record in truth_records}
    tp = len(predicted & truth)
    fp = len(predicted - truth)
    fn = len(truth - predicted)
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0

    truth_by_type: dict[str, set[str]] = defaultdict(set)
    pred_by_type: dict[str, set[str]] = defaultdict(set)
    for record in truth_records:
        truth_by_type[str(record["issue_type"])].add(truth_key(record))
    for issue in issues:
        pred_by_type[issue.issue_type].add(issue_truth_key(issue))

    per_type: dict[str, dict[str, Any]] = {}
    for issue_type in sorted(set(truth_by_type) | set(pred_by_type)):
        t = truth_by_type[issue_type]
        p = pred_by_type[issue_type]
        type_tp = len(t & p)
        type_fp = len(p - t)
        type_fn = len(t - p)
        type_precision = type_tp / (type_tp + type_fp) if type_tp + type_fp else 0.0
        type_recall = type_tp / (type_tp + type_fn) if type_tp + type_fn else 0.0
        per_type[issue_type] = {
            "true_positives": type_tp,
            "false_positives": type_fp,
            "false_negatives": type_fn,
            "precision": type_precision,
            "recall": type_recall,
            "f1": f1_score(type_precision, type_recall),
            "truth_count": len(t),
            "predicted_count": len(p),
        }

    return {
        "evaluation_unit": "typed cell/row/column coordinates",
        "true_positives": tp,
        "false_positives": fp,
        "false_negatives": fn,
        "precision": precision,
        "recall": recall,
        "f1": f1_score(precision, recall),
        "truth_count": len(truth),
        "predicted_count": len(predicted),
        "per_issue_type": per_type,
    }


def exact_reference_metrics(input_df: pd.DataFrame, reference_df: pd.DataFrame) -> dict[str, Any]:
    common_columns = [column for column in input_df.columns if column in reference_df.columns]
    common_rows = input_df.index.intersection(reference_df.index)
    left = input_df.loc[common_rows, common_columns]
    right = reference_df.loc[common_rows, common_columns]
    equal = pd.DataFrame(False, index=common_rows, columns=common_columns)
    for column in common_columns:
        l = left[column]
        r = right[column]
        both_missing = l.isna() & r.isna()
        if pd.api.types.is_numeric_dtype(l) and pd.api.types.is_numeric_dtype(r):
            values = np.isclose(
                pd.to_numeric(l, errors="coerce").to_numpy(float),
                pd.to_numeric(r, errors="coerce").to_numpy(float),
                equal_nan=False,
            )
            equal[column] = both_missing | pd.Series(values, index=common_rows)
        else:
            equal[column] = both_missing | l.astype("string").str.strip().eq(r.astype("string").str.strip()).fillna(False)
    wrong = ~equal
    wrong_count = int(wrong.to_numpy().sum())
    total = int(wrong.size)
    per_column = {
        column: {
            "wrong_cells": int(wrong[column].sum()),
            "exact_cell_accuracy": 1.0 - int(wrong[column].sum()) / max(1, len(common_rows)),
        }
        for column in common_columns
    }
    return {
        "aligned_rows": len(common_rows),
        "aligned_columns": len(common_columns),
        "total_cells": total,
        "wrong_cells": wrong_count,
        "exact_cell_accuracy": 1.0 - wrong_count / max(1, total),
        "per_column": per_column,
    }
