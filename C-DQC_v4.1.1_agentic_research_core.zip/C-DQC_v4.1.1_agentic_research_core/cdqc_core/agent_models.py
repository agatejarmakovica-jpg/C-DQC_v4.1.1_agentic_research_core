from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, model_validator

AllowedTool = Literal[
    "check_explicit_missingness",
    "check_missing_tokens",
    "check_disguised_missingness",
    "check_range_violations",
    "check_numeric_extremes",
    "check_categorical_consistency",
    "check_date_consistency",
    "check_format_consistency",
    "check_duplicates",
    "check_metadata_completeness",
    "check_privacy_documentation",
]

ALLOWED_TOOLS: tuple[str, ...] = (
    "check_explicit_missingness",
    "check_missing_tokens",
    "check_disguised_missingness",
    "check_range_violations",
    "check_numeric_extremes",
    "check_categorical_consistency",
    "check_date_consistency",
    "check_format_consistency",
    "check_duplicates",
    "check_metadata_completeness",
    "check_privacy_documentation",
)


class AgentDecision(BaseModel):
    """Schema-constrained policy decision returned by the LLM or fallback policy."""

    next_tool: AllowedTool | None = None
    target_columns: list[str] = Field(default_factory=list)
    reason: str = Field(min_length=3, max_length=1200)
    required_evidence: list[str] = Field(default_factory=list)
    stop: bool = False

    @model_validator(mode="after")
    def validate_stop_contract(self) -> "AgentDecision":
        if self.stop and self.next_tool is not None:
            raise ValueError("A stop decision must not select a tool.")
        if not self.stop and self.next_tool is None:
            raise ValueError("A non-stop decision must select exactly one tool.")
        return self
