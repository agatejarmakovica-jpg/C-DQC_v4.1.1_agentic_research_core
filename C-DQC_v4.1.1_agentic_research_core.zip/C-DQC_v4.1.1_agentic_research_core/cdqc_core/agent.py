from __future__ import annotations

from collections import Counter
import hashlib
import json
from typing import Any, Literal, TypedDict

import pandas as pd
from langgraph.graph import END, START, StateGraph

from .agent_models import ALLOWED_TOOLS, AgentDecision
from .llm_policy import POLICY_PROMPT_VERSION, Policy, build_policy
from .models import Issue
from .profile import build_dataset_profile
from .selective_detectors import execute_detector_tool
from .verdict import determine_reuse_verdict


class AgentState(TypedDict):
    profile: dict[str, Any]
    remaining_tools: list[str]
    executed_tools: list[str]
    issues: list[Issue]
    decision_log: list[dict[str, Any]]
    step_count: int
    max_steps: int
    current_decision: dict[str, Any] | None
    stop_reason: str | None


def _validate_decision(decision: AgentDecision, state: AgentState) -> AgentDecision:
    if decision.stop:
        return decision
    if decision.next_tool not in state["remaining_tools"]:
        raise ValueError(f"Policy selected unavailable or repeated tool: {decision.next_tool}")
    known_columns = {column["name"] for column in state["profile"].get("columns", [])}
    unknown = sorted(set(decision.target_columns) - known_columns)
    if unknown:
        raise ValueError(f"Policy selected unknown target columns: {unknown}")
    return decision


def run_agentic_assessment(
    df: pd.DataFrame,
    config: dict[str, Any],
    *,
    policy: Policy | None = None,
) -> dict[str, Any]:
    agent_config = config.get("agentic", {}) or {}
    max_steps = int(agent_config.get("max_steps", 8))
    if max_steps < 1:
        raise ValueError("agentic.max_steps must be at least 1.")
    policy = policy or build_policy(agent_config)
    profile = build_dataset_profile(df, config)
    profile_sha256 = hashlib.sha256(
        json.dumps(profile, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()

    def plan_node(state: AgentState) -> dict[str, Any]:
        result = policy.select_next_action(dict(state))
        decision = _validate_decision(result.decision, state)
        entry = {
            "decision_index": len(state["decision_log"]) + 1,
            "step_before_execution": state["step_count"],
            "provider": result.provider,
            "prompt_version": POLICY_PROMPT_VERSION,
            "profile_sha256": profile_sha256,
            "decision_status": "accepted",
            "model": result.model,
            "fallback_used": result.fallback_used,
            "policy_error": result.error,
            "usage": result.usage,
            **decision.model_dump(),
            "tool_result_count": None,
            "issue_counts_after_tool": None,
        }
        stop_reason = decision.reason if decision.stop else state["stop_reason"]
        return {
            "current_decision": decision.model_dump(),
            "decision_log": [*state["decision_log"], entry],
            "stop_reason": stop_reason,
        }

    def execute_node(state: AgentState) -> dict[str, Any]:
        decision = AgentDecision.model_validate(state["current_decision"])
        assert decision.next_tool is not None
        new_issues = execute_detector_tool(
            decision.next_tool,
            df,
            config,
            decision.target_columns or None,
        )
        all_issues = {issue.issue_id: issue for issue in [*state["issues"], *new_issues]}
        issues = sorted(
            all_issues.values(),
            key=lambda item: (
                item.issue_type,
                "" if item.column is None else item.column,
                -1 if item.row_index is None else item.row_index,
            ),
        )
        log = [dict(entry) for entry in state["decision_log"]]
        log[-1]["tool_result_count"] = len(new_issues)
        log[-1]["issue_counts_after_tool"] = dict(sorted(Counter(issue.issue_type for issue in issues).items()))
        remaining = [tool for tool in state["remaining_tools"] if tool != decision.next_tool]
        return {
            "issues": issues,
            "executed_tools": [*state["executed_tools"], decision.next_tool],
            "remaining_tools": remaining,
            "decision_log": log,
            "step_count": state["step_count"] + 1,
            "current_decision": None,
        }

    def finalize_node(state: AgentState) -> dict[str, Any]:
        reason = state["stop_reason"]
        if reason is None and state["step_count"] >= state["max_steps"]:
            reason = "Maximum agent step budget reached."
        elif reason is None and not state["remaining_tools"]:
            reason = "All detector tools were exhausted."
        return {"stop_reason": reason or "Policy terminated assessment."}

    def route_after_plan(state: AgentState) -> Literal["execute", "finalize"]:
        decision = AgentDecision.model_validate(state["current_decision"])
        return "finalize" if decision.stop else "execute"

    def route_after_execute(state: AgentState) -> Literal["plan", "finalize"]:
        if state["step_count"] >= state["max_steps"] or not state["remaining_tools"]:
            return "finalize"
        return "plan"

    builder = StateGraph(AgentState)
    builder.add_node("plan", plan_node)
    builder.add_node("execute", execute_node)
    builder.add_node("finalize", finalize_node)
    builder.add_edge(START, "plan")
    builder.add_conditional_edges("plan", route_after_plan, {"execute": "execute", "finalize": "finalize"})
    builder.add_conditional_edges("execute", route_after_execute, {"plan": "plan", "finalize": "finalize"})
    builder.add_edge("finalize", END)
    graph = builder.compile()

    initial: AgentState = {
        "profile": profile,
        "remaining_tools": list(ALLOWED_TOOLS),
        "executed_tools": [],
        "issues": [],
        "decision_log": [],
        "step_count": 0,
        "max_steps": max_steps,
        "current_decision": None,
        "stop_reason": None,
    }
    final = graph.invoke(initial)
    issues = list(final["issues"])
    verdict = determine_reuse_verdict(issues, list(final["executed_tools"]), config)
    return {
        "profile": profile,
        "issues": issues,
        "decision_log": list(final["decision_log"]),
        "executed_tools": list(final["executed_tools"]),
        "remaining_tools": list(final["remaining_tools"]),
        "step_count": int(final["step_count"]),
        "max_steps": int(final["max_steps"]),
        "stop_reason": final["stop_reason"],
        "verdict": verdict,
        "graph": {
            "engine": "LangGraph StateGraph",
            "nodes": ["plan", "execute", "finalize"],
            "dynamic_tool_selection": True,
        },
    }
