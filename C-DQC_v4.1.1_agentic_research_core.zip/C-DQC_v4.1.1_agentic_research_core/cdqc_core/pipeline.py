from __future__ import annotations

from datetime import datetime, timezone
import json
from pathlib import Path
from typing import Any

import pandas as pd

from . import __version__
from .detectors import detect_issues
from .metrics import detection_metrics, exact_reference_metrics, quality_support_metrics
from .recommend import recommendations_for
from .utils import read_json, sha256_file, write_json


def _read_table(path: Path) -> pd.DataFrame:
    suffix = path.suffix.casefold()
    if suffix == ".csv":
        return pd.read_csv(path, low_memory=False)
    if suffix in {".xlsx", ".xls"}:
        return pd.read_excel(path)
    if suffix == ".parquet":
        return pd.read_parquet(path)
    raise ValueError(f"Unsupported input format: {suffix}")


def run_assessment(
    input_path: Path,
    output_dir: Path,
    config_path: Path | None = None,
    reference_path: Path | None = None,
    truth_manifest_path: Path | None = None,
) -> dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    config = read_json(config_path) if config_path else {}
    df = _read_table(input_path)
    agentic_config = config.get("agentic", {}) or {}
    agent_result = None
    if bool(agentic_config.get("enabled", False)):
        from .agent import run_agentic_assessment

        agent_result = run_agentic_assessment(df, config)
        issues = agent_result["issues"]
    else:
        issues = detect_issues(df, config)
    recommendations = recommendations_for(issues)

    # Stable primary-output contract: source snapshot remains unchanged and retains its original schema.
    source_snapshot = output_dir / f"input_snapshot{input_path.suffix.casefold()}"
    if input_path.suffix.casefold() == ".csv":
        df.to_csv(source_snapshot, index=False)
    elif input_path.suffix.casefold() in {".xlsx", ".xls"}:
        df.to_excel(source_snapshot, index=False)
    else:
        df.to_parquet(source_snapshot, index=False)

    issue_rows = []
    for issue in issues:
        row = issue.to_dict()
        row["evidence"] = json.dumps(row["evidence"], ensure_ascii=False, sort_keys=True)
        issue_rows.append(row)
    pd.DataFrame(issue_rows).to_csv(output_dir / "issues.csv", index=False)
    write_json(output_dir / "issues.json", [issue.to_dict() for issue in issues])

    recommendation_rows = []
    for recommendation in recommendations:
        row = recommendation.to_dict()
        row["prerequisites"] = json.dumps(row["prerequisites"], ensure_ascii=False)
        row["issue_ids"] = json.dumps(row["issue_ids"], ensure_ascii=False)
        recommendation_rows.append(row)
    pd.DataFrame(recommendation_rows).to_csv(output_dir / "recommendations.csv", index=False)


    if agent_result is not None:
        write_json(output_dir / "dataset_profile.json", agent_result["profile"])
        write_json(output_dir / "agent_trace.json", agent_result["decision_log"])
        trace_rows = []
        for entry in agent_result["decision_log"]:
            row = dict(entry)
            for key in ("target_columns", "required_evidence", "usage", "issue_counts_after_tool"):
                row[key] = json.dumps(row.get(key), ensure_ascii=False, sort_keys=True)
            trace_rows.append(row)
        pd.DataFrame(trace_rows).to_csv(output_dir / "agent_decisions.csv", index=False)
        tool_rows = [
            {
                "execution_order": index,
                "tool": entry.get("next_tool"),
                "target_columns": json.dumps(entry.get("target_columns", []), ensure_ascii=False),
                "tool_result_count": entry.get("tool_result_count"),
                "fallback_used": entry.get("fallback_used", False),
                "policy_error": entry.get("policy_error"),
            }
            for index, entry in enumerate(agent_result["decision_log"], start=1)
            if entry.get("next_tool")
        ]
        pd.DataFrame(tool_rows).to_csv(output_dir / "tool_execution_log.csv", index=False)
        write_json(output_dir / "reuse_readiness_verdict.json", agent_result["verdict"])
        write_json(
            output_dir / "agent_summary.json",
            {
                "graph": agent_result["graph"],
                "executed_tools": agent_result["executed_tools"],
                "remaining_tools": agent_result["remaining_tools"],
                "step_count": agent_result["step_count"],
                "max_steps": agent_result["max_steps"],
                "stop_reason": agent_result["stop_reason"],
                "verdict": agent_result["verdict"]["verdict"],
            },
        )

    support_metrics = quality_support_metrics(
        df, issues, config,
        executed_tools=agent_result["executed_tools"] if agent_result is not None else None,
    )
    write_json(output_dir / "quality_support_metrics.json", support_metrics)

    reference_metrics = None
    if reference_path:
        reference_df = _read_table(reference_path)
        reference_metrics = exact_reference_metrics(df, reference_df)
        write_json(output_dir / "reference_exact_metrics.json", reference_metrics)

    benchmark_metrics = None
    if truth_manifest_path:
        truth_df = pd.read_csv(truth_manifest_path)
        benchmark_metrics = detection_metrics(issues, truth_df.to_dict(orient="records"))
        write_json(output_dir / "detection_benchmark_metrics.json", benchmark_metrics)

    manifest = {
        "software": "C-DQC Research Core",
        "version": __version__,
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "dataset_id": config.get("dataset_id", input_path.stem),
        "input_file": str(input_path),
        "input_sha256": sha256_file(input_path),
        "config_file": str(config_path) if config_path else None,
        "config_sha256": sha256_file(config_path) if config_path else None,
        "reference_file": str(reference_path) if reference_path else None,
        "truth_manifest_file": str(truth_manifest_path) if truth_manifest_path else None,
        "row_count": int(len(df)),
        "column_count": int(len(df.columns)),
        "issue_count": len(issues),
        "recommendation_count": len(recommendations),
        "execution_mode": "agentic" if agent_result is not None else "fixed_pipeline",
        "agentic_execution": (
            {
                "engine": agent_result["graph"]["engine"],
                "executed_tools": agent_result["executed_tools"],
                "step_count": agent_result["step_count"],
                "max_steps": agent_result["max_steps"],
                "stop_reason": agent_result["stop_reason"],
                "verdict": agent_result["verdict"]["verdict"],
                "aggregate_profile_only": True,
                "automatic_data_repair": False,
            }
            if agent_result is not None
            else None
        ),
        "primary_output_contract": {
            "source_snapshot_preserves_original_schema": True,
            "audit_information_is_separate": True,
            "automatic_data_repair": False,
        },
        "scientific_claim_boundary": {
            "no_reference_metrics_are_support_scores_not_ground_truth_accuracy": True,
            "candidate_issues_are_not_confirmed_errors": True,
            "reference_or_injection_manifest_required_for_precision_recall_f1": True,
        },
    }
    write_json(output_dir / "run_manifest.json", manifest)
    return {
        "manifest": manifest,
        "quality_support_metrics": support_metrics,
        "reference_metrics": reference_metrics,
        "benchmark_metrics": benchmark_metrics,
    }
