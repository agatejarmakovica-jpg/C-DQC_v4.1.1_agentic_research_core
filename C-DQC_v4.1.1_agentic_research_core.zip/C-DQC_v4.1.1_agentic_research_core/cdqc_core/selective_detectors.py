from __future__ import annotations

from collections import Counter, defaultdict
import re
from typing import Any, Callable

import numpy as np
import pandas as pd

from .detectors import (
    DEFAULT_MISSING_TOKENS,
    _issue,
    _numeric_sentinel_candidates,
    _target_format_matches,
    infer_role,
)
from .models import Issue
from .utils import exact_text, normalized_text


def _columns(df: pd.DataFrame, target_columns: list[str] | None) -> list[str]:
    if not target_columns:
        return [str(column) for column in df.columns]
    unknown = sorted(set(target_columns) - {str(column) for column in df.columns})
    if unknown:
        raise ValueError(f"Unknown target columns: {unknown}")
    return list(dict.fromkeys(target_columns))


def _stable(issues: list[Issue]) -> list[Issue]:
    unique = {issue.issue_id: issue for issue in issues}
    return sorted(
        unique.values(),
        key=lambda item: (
            item.issue_type,
            "" if item.column is None else item.column,
            -1 if item.row_index is None else item.row_index,
        ),
    )


def check_duplicates(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    issues: list[Issue] = []
    duplicate_mask = df.duplicated(keep="first")
    for position, row_index in enumerate(df.index):
        if not bool(duplicate_mask.loc[row_index]):
            continue
        prior = df.iloc[:position]
        current = df.iloc[position]
        matches = prior.eq(current).all(axis=1)
        duplicate_of = int(matches.index[matches][0]) if matches.any() else None
        issues.append(
            _issue("exact_duplicate_row", "row", None, int(row_index), None, "confirmed", 1.0, 0.7, {"duplicate_of": duplicate_of})
        )
    return _stable(issues)


def check_explicit_missingness(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    issues: list[Issue] = []
    for column in _columns(df, target_columns):
        series = df[column]
        missing_rows = series.index[series.isna()].tolist()
        missing_rate = len(missing_rows) / max(1, len(series))
        for row_index in missing_rows:
            issues.append(
                _issue("explicit_missingness", "cell", column, int(row_index), None, "confirmed", 1.0, max(0.1, missing_rate), {"source": "pandas_isna"})
            )
    return _stable(issues)


def check_missing_tokens(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    declared = {str(token).strip().casefold() for token in config.get("missing_tokens", [])}
    heuristic = DEFAULT_MISSING_TOKENS - declared
    issues: list[Issue] = []
    for column in _columns(df, target_columns):
        series = df[column]
        if not (pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series)):
            continue
        text = series.astype("string").str.strip().str.casefold()
        for row_index in series.index[series.notna() & text.isin(declared)]:
            issues.append(
                _issue("explicit_missing_token", "cell", column, int(row_index), series.loc[row_index], "confirmed", 1.0, 0.6, {"token_source": "dataset_config"}, True)
            )
        for row_index in series.index[series.notna() & text.isin(heuristic)]:
            issues.append(
                _issue("suspected_missing_token", "cell", column, int(row_index), series.loc[row_index], "candidate", 0.65, 0.4, {"token_source": "generic_lexicon", "requires_confirmation": True})
            )
    return _stable(issues)


def check_disguised_missingness(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    column_cfg = config.get("columns", {}) or {}
    issues: list[Issue] = []
    for column in _columns(df, target_columns):
        series = df[column]
        meta = column_cfg.get(column, {}) or {}
        sentinel_values = meta.get("sentinel_values", {}) or {}
        for raw_value, meaning in sentinel_values.items():
            if pd.api.types.is_numeric_dtype(series):
                mask = pd.to_numeric(series, errors="coerce").eq(float(raw_value))
            else:
                mask = series.astype("string").str.strip().eq(str(raw_value))
            for row_index in series.index[mask.fillna(False)]:
                is_missing = str(meaning).casefold() == "missing"
                issues.append(
                    _issue(
                        "confirmed_disguised_missingness" if is_missing else "confirmed_sentinel_value",
                        "cell", column, int(row_index), series.loc[row_index], "confirmed", 1.0, 0.8,
                        {"meaning": meaning, "source": "dataset_config"}, is_missing,
                    )
                )
        if pd.api.types.is_numeric_dtype(series) and not sentinel_values:
            for candidate in _numeric_sentinel_candidates(series):
                mask = pd.to_numeric(series, errors="coerce").eq(candidate["candidate"])
                for row_index in series.index[mask.fillna(False)]:
                    issues.append(
                        _issue(
                            "disguised_missingness_candidate", "cell", column, int(row_index), series.loc[row_index],
                            "candidate", candidate["score"], min(1.0, candidate["frequency_share"] * 2 + 0.2),
                            {**candidate, "requires_dataset_metadata": True},
                        )
                    )
    return _stable(issues)


def check_range_violations(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    column_cfg = config.get("columns", {}) or {}
    issues: list[Issue] = []
    for column in _columns(df, target_columns):
        series = df[column]
        valid_range = (column_cfg.get(column, {}) or {}).get("valid_range")
        if valid_range is None or not pd.api.types.is_numeric_dtype(series):
            continue
        low, high = float(valid_range[0]), float(valid_range[1])
        numeric = pd.to_numeric(series, errors="coerce")
        mask = numeric.notna() & ((numeric < low) | (numeric > high))
        for row_index in series.index[mask]:
            issues.append(
                _issue("range_violation", "cell", column, int(row_index), series.loc[row_index], "confirmed", 1.0, 0.8, {"valid_range": [low, high], "source": "dataset_config"})
            )
    return _stable(issues)


def check_numeric_extremes(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    column_cfg = config.get("columns", {}) or {}
    issues: list[Issue] = []
    for column in _columns(df, target_columns):
        series = df[column]
        if not pd.api.types.is_numeric_dtype(series):
            continue
        numeric = pd.to_numeric(series, errors="coerce")
        observed = numeric.dropna()
        if len(observed) < 20:
            continue
        excluded_rows: set[int] = set()
        sentinel_values = (column_cfg.get(column, {}) or {}).get("sentinel_values", {}) or {}
        for raw_value in sentinel_values:
            mask = numeric.eq(float(raw_value))
            excluded_rows.update(int(idx) for idx in series.index[mask.fillna(False)])
        if not sentinel_values:
            for candidate in _numeric_sentinel_candidates(series):
                mask = numeric.eq(candidate["candidate"])
                excluded_rows.update(int(idx) for idx in series.index[mask.fillna(False)])
        q1, q3 = observed.quantile([0.25, 0.75])
        iqr = float(q3 - q1)
        median = float(observed.median())
        mad = float(np.median(np.abs(observed - median)))
        if iqr > 0:
            outer = observed[(observed < float(q1 - 3.0 * iqr)) | (observed > float(q3 + 3.0 * iqr))]
        elif mad > 0:
            robust_z = 0.6745 * (observed - median) / mad
            outer = observed[robust_z.abs() > 4.5]
        else:
            outer = observed.iloc[0:0]
        for row_index, value in outer.items():
            if int(row_index) in excluded_rows:
                continue
            issues.append(
                _issue("numeric_extreme_candidate", "cell", column, int(row_index), value, "candidate", 0.75, 0.35, {"method": "outer_tukey_or_robust_z", "requires_domain_confirmation": True})
            )
    return _stable(issues)


def check_categorical_consistency(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    column_cfg = config.get("columns", {}) or {}
    issues: list[Issue] = []
    for column in _columns(df, target_columns):
        series = df[column]
        meta = column_cfg.get(column, {}) or {}
        role = str(meta.get("role") or infer_role(column, series)).casefold()
        if role != "categorical" and not meta.get("allowed_values"):
            continue
        groups: dict[str, list[tuple[int, str]]] = defaultdict(list)
        for row_index, value in series.dropna().items():
            key = normalized_text(value)
            if key is not None:
                groups[key].append((int(row_index), exact_text(value) or ""))
        allowed_values = [str(value) for value in meta.get("allowed_values", [])]
        allowed_normalized = {normalized_text(value): value for value in allowed_values}
        for key, entries in groups.items():
            raw_counts = Counter(raw for _, raw in entries)
            canonical = allowed_normalized.get(key) or sorted(raw_counts.items(), key=lambda item: (-item[1], item[0]))[0][0]
            if len(raw_counts) <= 1 and (not allowed_values or key in allowed_normalized):
                continue
            for row_index, raw in entries:
                if allowed_values and key not in allowed_normalized:
                    issue_type, status, confidence = "categorical_invalid_value", "confirmed", 1.0
                elif raw != canonical:
                    issue_type, status, confidence = "categorical_representation_inconsistency", "supported", 0.9
                else:
                    continue
                issues.append(
                    _issue(issue_type, "cell", column, row_index, series.loc[row_index], status, confidence, 0.5, {"canonical": canonical, "variant_group": sorted(raw_counts), "allowed_values": allowed_values}, bool(meta.get("canonical_mapping")))
                )
    return _stable(issues)


def check_date_consistency(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    column_cfg = config.get("columns", {}) or {}
    issues: list[Issue] = []
    for column in _columns(df, target_columns):
        series = df[column]
        meta = column_cfg.get(column, {}) or {}
        role = str(meta.get("role") or infer_role(column, series)).casefold()
        if role != "date":
            continue
        observed = series.dropna().astype(str).str.strip()
        parsed = pd.to_datetime(observed, errors="coerce", format="mixed")
        for row_index in observed.index[parsed.isna()]:
            issues.append(_issue("unparseable_date", "cell", column, int(row_index), series.loc[row_index], "supported", 0.95, 0.6, {"parser": "pandas_mixed"}))
        target_format = meta.get("target_format")
        if target_format:
            for row_index, value in observed[parsed.notna()].items():
                if not _target_format_matches(value, str(target_format)):
                    issues.append(
                        _issue("date_format_inconsistency", "cell", column, int(row_index), series.loc[row_index], "confirmed", 1.0, 0.35, {"target_format": target_format, "source": "dataset_config"}, bool(meta.get("allow_format_normalization", False)))
                    )
        else:
            raw_patterns = observed[parsed.notna()].map(lambda value: re.sub(r"\d", "#", value)).nunique()
            if raw_patterns > 1:
                issues.append(_issue("date_representation_diversity", "column", column, None, None, "candidate", 0.6, 0.2, {"pattern_count": int(raw_patterns), "not_a_cell_level_error": True}))
    return _stable(issues)


def check_format_consistency(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    column_cfg = config.get("columns", {}) or {}
    issues: list[Issue] = []
    for column in _columns(df, target_columns):
        series = df[column]
        regex = (column_cfg.get(column, {}) or {}).get("regex")
        if not regex:
            continue
        observed = series.dropna().astype(str)
        valid = observed.str.fullmatch(str(regex), na=False)
        for row_index in observed.index[~valid]:
            issues.append(_issue("format_inconsistency", "cell", column, int(row_index), series.loc[row_index], "confirmed", 1.0, 0.5, {"regex": regex, "source": "dataset_config"}))
    return _stable(issues)


def check_metadata_completeness(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    column_cfg = config.get("columns", {}) or {}
    required_fields = list(config.get("metadata_required_fields", []))
    issues: list[Issue] = []
    if required_fields:
        for column in _columns(df, target_columns):
            meta = column_cfg.get(column, {}) or {}
            missing = [field for field in required_fields if meta.get(field) in (None, "", [], {})]
            if missing:
                issues.append(_issue("schema_metadata_gap", "column", column, None, None, "confirmed", 1.0, min(1.0, len(missing) / len(required_fields)), {"missing_fields": missing}))
    dataset_metadata = config.get("dataset_metadata", {}) or {}
    dataset_required = list(config.get("dataset_metadata_required_fields", []))
    missing_dataset = [field for field in dataset_required if dataset_metadata.get(field) in (None, "", [], {})]
    if missing_dataset:
        issues.append(_issue("dataset_metadata_gap", "dataset", None, None, None, "confirmed", 1.0, min(1.0, len(missing_dataset) / max(1, len(dataset_required))), {"missing_fields": missing_dataset}))
    return _stable(issues)


def check_privacy_documentation(df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    privacy_status = (config.get("dataset_metadata", {}) or {}).get("privacy_status")
    if privacy_status not in (None, "", [], {}):
        return []
    return [
        _issue("privacy_documentation_gap", "dataset", None, None, None, "confirmed", 1.0, 0.9, {"required_field": "privacy_status", "blocking_for_reuse_verdict": True})
    ]


TOOL_REGISTRY: dict[str, Callable[[pd.DataFrame, dict[str, Any], list[str] | None], list[Issue]]] = {
    "check_explicit_missingness": check_explicit_missingness,
    "check_missing_tokens": check_missing_tokens,
    "check_disguised_missingness": check_disguised_missingness,
    "check_range_violations": check_range_violations,
    "check_numeric_extremes": check_numeric_extremes,
    "check_categorical_consistency": check_categorical_consistency,
    "check_date_consistency": check_date_consistency,
    "check_format_consistency": check_format_consistency,
    "check_duplicates": check_duplicates,
    "check_metadata_completeness": check_metadata_completeness,
    "check_privacy_documentation": check_privacy_documentation,
}

TOOL_DESCRIPTIONS: dict[str, str] = {
    "check_explicit_missingness": "Detect null cells using dataframe-native missingness semantics.",
    "check_missing_tokens": "Detect declared and heuristic textual missing-value tokens.",
    "check_disguised_missingness": "Check declared sentinels and distribution-supported boundary sentinel candidates.",
    "check_range_violations": "Check numeric values against dataset-scoped valid ranges.",
    "check_numeric_extremes": "Identify robust statistical extreme candidates without declaring them errors.",
    "check_categorical_consistency": "Check categorical label validity and representation consistency.",
    "check_date_consistency": "Check date parseability and declared representation requirements.",
    "check_format_consistency": "Check values against declared regular-expression formats.",
    "check_duplicates": "Detect exact duplicate rows.",
    "check_metadata_completeness": "Check required dataset- and column-level documentation fields.",
    "check_privacy_documentation": "Check whether the dataset privacy status is documented.",
}


def execute_detector_tool(tool: str, df: pd.DataFrame, config: dict[str, Any], target_columns: list[str] | None = None) -> list[Issue]:
    try:
        detector = TOOL_REGISTRY[tool]
    except KeyError as exc:
        raise ValueError(f"Unsupported detector tool: {tool}") from exc
    return detector(df, config, target_columns)
