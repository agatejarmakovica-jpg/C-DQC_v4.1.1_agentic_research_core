from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime
import math
import re
from typing import Any

import numpy as np
import pandas as pd

from .models import Issue
from .utils import exact_text, normalized_text, stable_id

DEFAULT_MISSING_TOKENS = {"na", "n/a", "null", "none", "missing", "?", "-"}


def infer_role(column: str, series: pd.Series) -> str:
    name = column.casefold()
    if pd.api.types.is_numeric_dtype(series):
        return "numeric"
    if any(token in name for token in ("date", "time", "dob")):
        return "date"
    if any(token in name for token in ("email", "mail")):
        return "email"
    if any(token in name for token in ("phone", "mobile", "telephone")):
        return "phone"
    observed = series.dropna()
    if len(observed) and observed.nunique() <= max(20, int(math.sqrt(len(observed)))):
        return "categorical"
    return "text"


def _issue(
    issue_type: str,
    scope: str,
    column: str | None,
    row_index: int | None,
    value: Any,
    evidence_status: str,
    confidence: float,
    severity: float,
    evidence: dict[str, Any],
    automatic_action_allowed: bool = False,
) -> Issue:
    issue_id = stable_id(issue_type, scope, column, row_index, repr(value))
    return Issue(
        issue_id=issue_id,
        issue_type=issue_type,
        scope=scope,  # type: ignore[arg-type]
        column=column,
        row_index=row_index,
        value=value,
        evidence_status=evidence_status,  # type: ignore[arg-type]
        confidence=float(np.clip(confidence, 0.0, 1.0)),
        severity=float(np.clip(severity, 0.0, 1.0)),
        evidence=evidence,
        automatic_action_allowed=automatic_action_allowed,
    )


def _target_format_matches(value: str, target_format: str) -> bool:
    try:
        parsed = datetime.strptime(value, target_format)
        return parsed.strftime(target_format) == value
    except (TypeError, ValueError):
        return False


def _numeric_sentinel_candidates(series: pd.Series) -> list[dict[str, Any]]:
    numeric = pd.to_numeric(series, errors="coerce").dropna()
    if len(numeric) < 20 or numeric.nunique() < 3:
        return []
    counts = numeric.value_counts(dropna=True)
    values = np.sort(numeric.unique().astype(float))
    adjacent = np.diff(values)
    positive_adjacent = adjacent[adjacent > 0]
    if len(positive_adjacent) == 0:
        return []
    typical_gap = float(np.median(positive_adjacent))
    if not np.isfinite(typical_gap) or typical_gap <= 0:
        return []

    results: list[dict[str, Any]] = []
    for position, candidate in (("minimum", float(values[0])), ("maximum", float(values[-1]))):
        gap = float(values[1] - values[0]) if position == "minimum" else float(values[-1] - values[-2])
        relative_gap = gap / typical_gap
        frequency = int(counts.get(candidate, 0))
        share = frequency / len(numeric)
        gap_score = min(1.0, relative_gap / 5.0)
        frequency_score = min(1.0, share / 0.05)
        score = 0.55 * gap_score + 0.25 * frequency_score + 0.20
        if score >= 0.72 and relative_gap >= 2.5 and frequency >= 2:
            results.append(
                {
                    "candidate": candidate,
                    "position": position,
                    "frequency": frequency,
                    "frequency_share": share,
                    "gap": gap,
                    "typical_adjacent_gap": typical_gap,
                    "relative_gap": relative_gap,
                    "score": score,
                }
            )
    return results


def detect_issues(df: pd.DataFrame, config: dict[str, Any] | None = None) -> list[Issue]:
    config = config or {}
    column_cfg = config.get("columns", {}) or {}
    declared_missing_tokens = {
        str(token).strip().casefold() for token in config.get("missing_tokens", [])
    }
    heuristic_missing_tokens = DEFAULT_MISSING_TOKENS - declared_missing_tokens
    issues: list[Issue] = []
    sentinel_rows_by_column: dict[str, set[int]] = defaultdict(set)

    # Exact duplicate rows are row-scoped, not broadcast to every cell.
    duplicate_mask = df.duplicated(keep="first")
    for position, row_index in enumerate(df.index):
        if not bool(duplicate_mask.loc[row_index]):
            continue
        prior = df.iloc[:position]
        current = df.iloc[position]
        matches = prior.eq(current).all(axis=1)
        duplicate_of = int(matches.index[matches][0]) if matches.any() else None
        issues.append(
            _issue(
                "exact_duplicate_row",
                "row",
                None,
                int(row_index),
                None,
                "confirmed",
                1.0,
                0.7,
                {"duplicate_of": duplicate_of},
            )
        )

    for column in df.columns:
        series = df[column]
        meta = column_cfg.get(column, {}) or {}
        role = str(meta.get("role") or infer_role(str(column), series)).casefold()

        # Explicit missingness: exact cell coordinates.
        missing_rows = series.index[series.isna()].tolist()
        missing_rate = len(missing_rows) / max(1, len(series))
        for row_index in missing_rows:
            issues.append(
                _issue(
                    "explicit_missingness",
                    "cell",
                    str(column),
                    int(row_index),
                    None,
                    "confirmed",
                    1.0,
                    max(0.1, missing_rate),
                    {"source": "pandas_isna"},
                )
            )

        # Textual missing tokens. Declared tokens are confirmed; standard heuristics remain candidates.
        if pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series):
            text = series.astype("string").str.strip().str.casefold()
            for row_index in series.index[series.notna() & text.isin(declared_missing_tokens)]:
                issues.append(
                    _issue(
                        "explicit_missing_token",
                        "cell",
                        str(column),
                        int(row_index),
                        series.loc[row_index],
                        "confirmed",
                        1.0,
                        0.6,
                        {"token_source": "dataset_config"},
                        automatic_action_allowed=True,
                    )
                )
            for row_index in series.index[series.notna() & text.isin(heuristic_missing_tokens)]:
                issues.append(
                    _issue(
                        "suspected_missing_token",
                        "cell",
                        str(column),
                        int(row_index),
                        series.loc[row_index],
                        "candidate",
                        0.65,
                        0.4,
                        {"token_source": "generic_lexicon", "requires_confirmation": True},
                    )
                )

        # Dataset-scoped known sentinel values are confirmed. Generic boundary candidates remain hypotheses.
        sentinel_values = meta.get("sentinel_values", {}) or {}
        for raw_value, meaning in sentinel_values.items():
            if pd.api.types.is_numeric_dtype(series):
                mask = pd.to_numeric(series, errors="coerce").eq(float(raw_value))
            else:
                mask = series.astype("string").str.strip().eq(str(raw_value))
            for row_index in series.index[mask.fillna(False)]:
                sentinel_rows_by_column[str(column)].add(int(row_index))
                issues.append(
                    _issue(
                        "confirmed_disguised_missingness" if str(meaning).casefold() == "missing" else "confirmed_sentinel_value",
                        "cell",
                        str(column),
                        int(row_index),
                        series.loc[row_index],
                        "confirmed",
                        1.0,
                        0.8,
                        {"meaning": meaning, "source": "dataset_config"},
                        automatic_action_allowed=str(meaning).casefold() == "missing",
                    )
                )

        if pd.api.types.is_numeric_dtype(series) and not sentinel_values:
            for candidate in _numeric_sentinel_candidates(series):
                value = candidate["candidate"]
                mask = pd.to_numeric(series, errors="coerce").eq(value)
                for row_index in series.index[mask.fillna(False)]:
                    sentinel_rows_by_column[str(column)].add(int(row_index))
                    issues.append(
                        _issue(
                            "disguised_missingness_candidate",
                            "cell",
                            str(column),
                            int(row_index),
                            series.loc[row_index],
                            "candidate",
                            candidate["score"],
                            min(1.0, candidate["frequency_share"] * 2 + 0.2),
                            {**candidate, "requires_dataset_metadata": True},
                        )
                    )

        # Valid range violations are confirmed only when the range is dataset-scoped metadata.
        valid_range = meta.get("valid_range")
        if valid_range is not None and pd.api.types.is_numeric_dtype(series):
            low, high = float(valid_range[0]), float(valid_range[1])
            numeric = pd.to_numeric(series, errors="coerce")
            mask = numeric.notna() & ((numeric < low) | (numeric > high))
            for row_index in series.index[mask]:
                issues.append(
                    _issue(
                        "range_violation",
                        "cell",
                        str(column),
                        int(row_index),
                        series.loc[row_index],
                        "confirmed",
                        1.0,
                        0.8,
                        {"valid_range": [low, high], "source": "dataset_config"},
                    )
                )

        # Robust numeric extremes are candidates only. Sentinel rows are excluded from this class.
        if pd.api.types.is_numeric_dtype(series):
            numeric = pd.to_numeric(series, errors="coerce")
            observed = numeric.dropna()
            if len(observed) >= 20:
                q1, q3 = observed.quantile([0.25, 0.75])
                iqr = float(q3 - q1)
                median = float(observed.median())
                mad = float(np.median(np.abs(observed - median)))
                if iqr > 0:
                    outer_low, outer_high = float(q1 - 3.0 * iqr), float(q3 + 3.0 * iqr)
                    outer = observed[(observed < outer_low) | (observed > outer_high)]
                elif mad > 0:
                    robust_z = 0.6745 * (observed - median) / mad
                    outer = observed[robust_z.abs() > 4.5]
                else:
                    outer = observed.iloc[0:0]
                for row_index, value in outer.items():
                    if int(row_index) in sentinel_rows_by_column[str(column)]:
                        continue
                    issues.append(
                        _issue(
                            "numeric_extreme_candidate",
                            "cell",
                            str(column),
                            int(row_index),
                            value,
                            "candidate",
                            0.75,
                            0.35,
                            {"method": "outer_tukey_or_robust_z", "requires_domain_confirmation": True},
                        )
                    )

        # Categorical representation variants: flag only non-canonical cells, never the whole column.
        if role == "categorical" or meta.get("allowed_values"):
            observed = series.dropna()
            groups: dict[str, list[tuple[int, str]]] = defaultdict(list)
            for row_index, value in observed.items():
                key = normalized_text(value)
                if key is not None:
                    groups[key].append((int(row_index), exact_text(value) or ""))
            allowed_values = [str(v) for v in meta.get("allowed_values", [])]
            allowed_normalized = {normalized_text(v): v for v in allowed_values}
            for key, entries in groups.items():
                raw_counts = Counter(raw for _, raw in entries)
                canonical = allowed_normalized.get(key)
                if canonical is None:
                    canonical = sorted(raw_counts.items(), key=lambda x: (-x[1], x[0]))[0][0]
                if len(raw_counts) > 1 or (allowed_values and key not in allowed_normalized):
                    for row_index, raw in entries:
                        if allowed_values and key not in allowed_normalized:
                            issue_type = "categorical_invalid_value"
                            status, confidence = "confirmed", 1.0
                        elif raw != canonical:
                            issue_type = "categorical_representation_inconsistency"
                            status, confidence = "supported", 0.9
                        else:
                            continue
                        issues.append(
                            _issue(
                                issue_type,
                                "cell",
                                str(column),
                                row_index,
                                series.loc[row_index],
                                status,
                                confidence,
                                0.5,
                                {"canonical": canonical, "variant_group": sorted(raw_counts), "allowed_values": allowed_values},
                                automatic_action_allowed=bool(meta.get("canonical_mapping")),
                            )
                        )

        # Date and generic regex formats. Without a declared target format, do not label all parseable dates defective.
        if role == "date":
            observed = series.dropna().astype(str).str.strip()
            parsed = pd.to_datetime(observed, errors="coerce", format="mixed")
            for row_index in observed.index[parsed.isna()]:
                issues.append(
                    _issue(
                        "unparseable_date",
                        "cell",
                        str(column),
                        int(row_index),
                        series.loc[row_index],
                        "supported",
                        0.95,
                        0.6,
                        {"parser": "pandas_mixed"},
                    )
                )
            target_format = meta.get("target_format")
            if target_format:
                for row_index, value in observed[parsed.notna()].items():
                    if not _target_format_matches(value, str(target_format)):
                        issues.append(
                            _issue(
                                "date_format_inconsistency",
                                "cell",
                                str(column),
                                int(row_index),
                                series.loc[row_index],
                                "confirmed",
                                1.0,
                                0.35,
                                {"target_format": target_format, "source": "dataset_config"},
                                automatic_action_allowed=bool(meta.get("allow_format_normalization", False)),
                            )
                        )
            else:
                raw_patterns = observed[parsed.notna()].map(
                    lambda value: re.sub(r"\d", "#", value)
                ).nunique()
                if raw_patterns > 1:
                    issues.append(
                        _issue(
                            "date_representation_diversity",
                            "column",
                            str(column),
                            None,
                            None,
                            "candidate",
                            0.6,
                            0.2,
                            {"pattern_count": int(raw_patterns), "not_a_cell_level_error": True},
                        )
                    )

        regex = meta.get("regex")
        if regex:
            observed = series.dropna().astype(str)
            valid = observed.str.fullmatch(str(regex), na=False)
            for row_index in observed.index[~valid]:
                issues.append(
                    _issue(
                        "format_inconsistency",
                        "cell",
                        str(column),
                        int(row_index),
                        series.loc[row_index],
                        "confirmed",
                        1.0,
                        0.5,
                        {"regex": regex, "source": "dataset_config"},
                    )
                )

    # Schema / documentation gaps are column-scoped. They are never converted into affected rows.
    required_fields = list(config.get("metadata_required_fields", []))
    if required_fields:
        for column in df.columns:
            meta = column_cfg.get(column, {}) or {}
            missing_fields = [field for field in required_fields if meta.get(field) in (None, "", [])]
            if missing_fields:
                issues.append(
                    _issue(
                        "schema_metadata_gap",
                        "column",
                        str(column),
                        None,
                        None,
                        "confirmed",
                        1.0,
                        min(1.0, len(missing_fields) / len(required_fields)),
                        {"missing_fields": missing_fields},
                    )
                )

    # Stable order and exact de-duplication.
    unique = {issue.issue_id: issue for issue in issues}
    return sorted(
        unique.values(),
        key=lambda item: (
            item.issue_type,
            "" if item.column is None else item.column,
            -1 if item.row_index is None else item.row_index,
        ),
    )
