"""C-DQC v4.1.1 agentic research core."""

__version__ = "4.1.1"
