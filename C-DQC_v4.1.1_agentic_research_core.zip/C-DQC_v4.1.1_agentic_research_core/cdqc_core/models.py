from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Literal

IssueScope = Literal["cell", "row", "column", "dataset"]
EvidenceStatus = Literal["confirmed", "supported", "candidate"]


@dataclass(frozen=True)
class Issue:
    issue_id: str
    issue_type: str
    scope: IssueScope
    column: str | None
    row_index: int | None
    value: Any
    evidence_status: EvidenceStatus
    confidence: float
    severity: float
    evidence: dict[str, Any] = field(default_factory=dict)
    automatic_action_allowed: bool = False

    def unit_key(self) -> str:
        return f"{self.scope}|{self.row_index}|{self.column}|{self.issue_type}"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass(frozen=True)
class Recommendation:
    issue_group_id: str
    issue_type: str
    column: str | None
    affected_count: int
    issue_ids: list[str]
    method: str
    rank: int
    rationale: str
    prerequisites: list[str]
    expected_risk: str
    application_mode: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
