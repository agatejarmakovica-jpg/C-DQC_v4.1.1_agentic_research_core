from __future__ import annotations

import argparse
from pathlib import Path

from .benchmark import run_repeated_benchmark
from .inject import write_injected_benchmark
from .pipeline import run_assessment


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="cdqc", description="C-DQC v4.1 agentic research core")
    sub = parser.add_subparsers(dest="command", required=True)

    assess = sub.add_parser("assess", help="Assess a tabular dataset without mutating it")
    assess.add_argument("--input", required=True, type=Path)
    assess.add_argument("--output", required=True, type=Path)
    assess.add_argument("--config", type=Path)
    assess.add_argument("--reference", type=Path)
    assess.add_argument("--truth-manifest", type=Path)

    inject = sub.add_parser("inject", help="Create one controlled synthetic benchmark")
    inject.add_argument("--output", required=True, type=Path)
    inject.add_argument("--seed", type=int, default=1000)
    inject.add_argument("--rows", type=int, default=600)

    benchmark = sub.add_parser("benchmark", help="Run the repeated synthetic benchmark")
    benchmark.add_argument("--output", required=True, type=Path)
    benchmark.add_argument("--runs", type=int, default=30)
    benchmark.add_argument("--rows", type=int, default=600)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    if args.command == "assess":
        result = run_assessment(
            input_path=args.input,
            output_dir=args.output,
            config_path=args.config,
            reference_path=args.reference,
            truth_manifest_path=args.truth_manifest,
        )
        print(result["manifest"])
    elif args.command == "inject":
        print(write_injected_benchmark(args.output, seed=args.seed, rows=args.rows))
    elif args.command == "benchmark":
        report = run_repeated_benchmark(args.output, runs=args.runs, rows=args.rows)
        print(report["benchmark_design"])


if __name__ == "__main__":
    main()
