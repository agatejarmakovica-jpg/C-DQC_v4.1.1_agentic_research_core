# Release notes — v4.0.0

## Added

- exact typed cell/row/column issue coordinates;
- explicit evidence states: confirmed, supported, candidate;
- stable output contract preserving the input schema;
- grouped, auditable method recommendations;
- reference-aligned exact cell accuracy;
- corruption-manifest precision, recall, and F1;
- per-defect metrics;
- 30-run benchmark with three difficulty regimes;
- bootstrap confidence intervals, paired Wilcoxon tests, and effect sizes;
- no-reference diabetes case study;
- 12 scientific-contract tests.

## Removed

- autonomous repair;
- counterfactual repair rollouts;
- LLM-based repair decisions;
- misleading proxy accuracy metrics;
- mutation of the primary dataset with generated audit columns.

## Known limitation

The current empirical validation includes one repeated synthetic benchmark and one no-reference public-style case study. External reference-aligned datasets are still required before a Q1/Q2 generalization claim.
