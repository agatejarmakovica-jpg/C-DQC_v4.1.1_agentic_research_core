# Results summary — v4.1 agentic integration

## Software validation

- Full automated test suite: **13 passed**.
- One-step LangGraph integration test: **passed**.
- Selected tool: `check_explicit_missingness`.
- Executed tool count: **1**.
- Detected issue count: **1**.
- Source snapshot preserved without schema mutation: **yes**.
- Agent trace, tool log, summary, and deterministic verdict written: **yes**.

## API failure behavior

An OpenAI-policy run was started without `OPENAI_API_KEY`. The configured fallback completed the same one-step assessment. The trace recorded:

- requested provider and model;
- `fallback_used: true`;
- the missing-key error;
- selected fallback tool;
- detector result count.

## Interpretation

This result verifies the bounded agentic execution contract and audit trail. It is not evidence that the LLM policy improves detector selection. A scientific comparison requires repeated live-policy runs against the fixed pipeline and deterministic-policy baseline using datasets with reference truth or controlled corruption manifests.
