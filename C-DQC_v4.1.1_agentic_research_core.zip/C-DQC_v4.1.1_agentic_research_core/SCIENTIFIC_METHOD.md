# Scientific method — C-DQC v4.1

## 1. Research object

The research object is a tabular dataset, its evidence-backed data-quality state, and the sequence of checks selected to assess fitness for a declared reuse purpose. Health-themed datasets are representative data-science benchmarks, not clinical studies.

## 2. Fixed and agentic conditions

Two execution conditions are available:

- **fixed pipeline**: the established v4.0 detector suite is executed in a predetermined order;
- **agentic policy**: a bounded policy dynamically selects one detector at a time from a closed catalogue and may stop before all checks are executed.

The conditions can be compared using executed-check count, verdict agreement, detection precision/recall/F1 when truth is available, runtime, token use, and repeated-run plan stability.

## 3. Agentic architecture

The LangGraph state machine implements:

```text
PROFILE → PLAN → EXECUTE_SELECTED_TOOL → PLAN OR STOP → DETERMINISTIC VERDICT
```

The LLM receives an aggregate-only dataset profile, reuse purpose, remaining tools, executed-tool history, and issue-count summaries. It does not receive source rows or direct cell values.

The LLM may:

- select one next detector from the closed catalogue;
- select existing target-column names;
- state the evidence required;
- stop within the configured step budget.

The LLM may not:

- create new detector functions;
- change source values;
- authorize repair;
- reinterpret candidate findings as confirmed errors;
- override deterministic detector evidence;
- assign the final reuse-readiness verdict.

## 4. Typed evaluation units

Every finding has exactly one scope:

- cell: `(row_index, column, issue_type)`;
- row: `(row_index, issue_type)`;
- column: `(column, issue_type)`;
- dataset: `(issue_type)`.

Column-scoped documentation gaps are not converted into affected rows. Duplicate rows are not expanded into all cells.

## 5. Evidence states

- `confirmed`: established by direct observation or dataset-scoped metadata;
- `supported`: strong structural evidence without full semantic proof;
- `candidate`: statistical or generic semantic hypothesis requiring confirmation.

A candidate is not reported as an error, and no automatic action is allowed for a candidate.

## 6. Independently executable detector tools

The agent can select among eleven deterministic tools:

1. explicit missingness;
2. textual missing tokens;
3. confirmed or candidate disguised missingness;
4. metadata-backed range violations;
5. robust numeric extreme candidates;
6. categorical validity and representation consistency;
7. date parseability and declared date representation;
8. declared generic format rules;
9. exact duplicate rows;
10. dataset and column metadata completeness;
11. privacy-status documentation.

Each tool executes its own algorithm. Agentic runs do not execute the complete fixed pipeline and filter the output retrospectively.

## 7. Reuse-readiness verdict

The final verdict is assigned by deterministic rules:

- `READY`;
- `CONDITIONALLY_READY`;
- `NOT_READY`;
- `INSUFFICIENT_EVIDENCE`.

A missing purpose-required check produces `INSUFFICIENT_EVIDENCE`. Missing privacy documentation can produce `NOT_READY` when the reuse purpose requires privacy evidence. Confirmed high-severity findings, metadata gaps, or unresolved candidates produce `CONDITIONALLY_READY` unless a stronger configured blocker applies.

## 8. No-reference metrics

No-reference mode reports support metrics rather than ground-truth accuracy. In agentic mode, the metrics explicitly record which checks were executed. A non-executed check is not interpreted as evidence that the corresponding defect is absent.

Reported quantities include:

- explicit completeness when assessed;
- confirmed validity support conditional on executed checks;
- suspected issue burden;
- duplicate-free rate when assessed;
- column and dataset metadata completeness;
- privacy documentation support;
- reuse-readiness support;
- assessment coverage.

## 9. Reference and injected-benchmark evaluation

For typed truth units `T` and predicted units `P`:

- precision = `|P ∩ T| / |P|`;
- recall = `|P ∩ T| / |T|`;
- F1 = harmonic mean of precision and recall.

Metrics are computed overall and by defect type. Exact cell accuracy is computed only across aligned input/reference cells.

## 10. Auditability and reproducibility

An agentic run stores:

- the aggregate policy profile;
- policy provider and model;
- structured decision at every step;
- target columns and rationale;
- API usage when available;
- policy errors and fallback status;
- detector result count;
- executed and remaining tools;
- stop reason;
- deterministic verdict.

The source-data snapshot is unchanged, and audit data are stored separately.

## 11. Current validation boundary

The packaged validation establishes software behavior for the deterministic tool path, LangGraph control flow, one selected-tool run, output contracts, and API-failure fallback. It does not by itself establish that an LLM policy is superior to the fixed pipeline. That claim requires repeated live-policy runs on benchmark datasets with known truth and comparison against fixed and deterministic-policy baselines.
