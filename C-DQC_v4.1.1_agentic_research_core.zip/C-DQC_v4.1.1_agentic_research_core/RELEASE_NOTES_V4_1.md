# Release notes — v4.1.0

## Added

- bounded OpenAI policy using schema-constrained `AgentDecision` output;
- LangGraph `StateGraph` with dynamic `plan → execute → plan/stop` routing;
- eleven independently executable deterministic detector tools;
- aggregate-only dataset profiling for API data minimization;
- deterministic fallback policy for CI, ablation, and API failure handling;
- deterministic reuse-readiness verdict layer;
- agent decision, tool execution, model usage, fallback, and stop-reason audit files;
- one-step local and OpenAI-policy integration-test script;
- one new automated agentic integration test.

## Preserved

- unchanged source-data snapshot;
- typed cell, row, column, and dataset issue coordinates;
- confirmed, supported, and candidate evidence states;
- no automatic repair;
- truth metrics only when a reference or corruption manifest is available.

## Validation status

- full test suite: 13 passed;
- deterministic one-step agentic integration test: passed;
- OpenAI failure/fallback path without an API key: passed and audited;
- live paid OpenAI request: not executed during packaging because no user credential was available or stored.
