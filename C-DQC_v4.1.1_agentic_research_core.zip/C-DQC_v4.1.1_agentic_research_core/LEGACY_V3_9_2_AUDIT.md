# Audit of C-DQC v3.9.2

The uploaded v3.9.2 package was inspected before developing v4.0. The following defects explain the misleading earlier results.

## 1. Technical success was treated as semantic resolution

`cdqc/operators.py`, datetime standardization:

- `success` and `technical_success` were true when values changed and untouched columns remained unchanged;
- `semantic_resolution_verified` was set to `changed > 0`;
- the resolution score was based on parseability.

A representation change therefore counted as semantically successful without demonstrating agreement with a reference value or an approved target semantics.

## 2. Incorrect repairs on already-corrupted cells were not counted as false corrections

`cdqc/reference_evaluation.py` defined false correction as:

```python
false_correction = ~corrupted & changed
```

This counts only damage to initially clean cells. A corrupted cell changed to another incorrect value is excluded. That is why 200 unsuccessful phone transformations could coexist with `false_corrections = 0`.

## 3. Date-format detection could label every parseable value

The detector compared raw strings with one target representation. If every source date was parseable but used another representation, every row could be marked as inconsistent even when no reference corruption existed.

V4.0 distinguishes:

- a declared target-format violation at cell scope;
- representation diversity without a declared target at column scope.

## 4. Reference detection omitted the v3.9.2 sentinel issue type

The reference evaluator's cell issue allow-list did not include the new `suspected_disguised_missingness` type. New detector output and evaluation logic were therefore not fully aligned.

## 5. Output schema was unstable

Some operators added derived or audit columns to the same dataframe used as the final dataset. Downstream evaluation then encountered a 10-column input and 13-column output.

V4.0 keeps the source snapshot unchanged and writes audit information separately.

## 6. Tests primarily established execution, not scientific validity

The passing test suite demonstrated that the graph, operators, and artifact generation executed. It did not establish defect-level precision, recall, F1, or exact repair correctness on independent repeated benchmarks.

## Decision

V3.9.2 is retained only as legacy evidence. It is not the scientific core of the new release. Autonomous repair and LLM decision authorization were removed until a validated detection and recommendation baseline exists.
