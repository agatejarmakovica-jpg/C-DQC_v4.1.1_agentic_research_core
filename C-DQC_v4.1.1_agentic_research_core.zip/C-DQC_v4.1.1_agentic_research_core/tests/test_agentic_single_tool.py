from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from cdqc_core.pipeline import run_assessment


def test_agentic_graph_executes_exactly_one_selected_tool(tmp_path: Path):
    input_path = tmp_path / "input.csv"
    config_path = tmp_path / "config.json"
    output = tmp_path / "out"
    pd.DataFrame({"A": [1.0, None, 3.0], "Outcome": [0, 1, 0]}).to_csv(input_path, index=False)
    config = {
        "dataset_metadata": {"privacy_status": "contains no personal data"},
        "metadata_required_fields": ["role", "description"],
        "reuse_purpose": {"required_tools": ["check_explicit_missingness", "check_metadata_completeness", "check_privacy_documentation"], "privacy_required": True},
        "agentic": {
            "enabled": True,
            "provider": "deterministic",
            "max_steps": 1,
            "required_tools": ["check_explicit_missingness", "check_metadata_completeness", "check_privacy_documentation"],
        },
        "columns": {
            "A": {"role": "numeric", "description": "test value"},
            "Outcome": {"role": "categorical", "description": "test label", "allowed_values": [0, 1]},
        },
    }
    config_path.write_text(json.dumps(config), encoding="utf-8")

    run_assessment(input_path, output, config_path=config_path)

    summary = json.loads((output / "agent_summary.json").read_text(encoding="utf-8"))
    trace = json.loads((output / "agent_trace.json").read_text(encoding="utf-8"))
    issues = json.loads((output / "issues.json").read_text(encoding="utf-8"))
    assert summary["graph"]["engine"] == "LangGraph StateGraph"
    assert summary["step_count"] == 1
    assert summary["executed_tools"] == ["check_explicit_missingness"]
    assert summary["verdict"] == "INSUFFICIENT_EVIDENCE"
    assert trace[0]["tool_result_count"] == 1
    assert [issue["issue_type"] for issue in issues] == ["explicit_missingness"]
