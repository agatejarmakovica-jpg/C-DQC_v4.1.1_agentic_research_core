from __future__ import annotations

from cdqc_core.models import Issue
from cdqc_core.verdict import determine_reuse_verdict


def test_config_cannot_weaken_minimum_reuse_evidence_contract():
    config = {
        "reuse_purpose": {
            "task": "general_tabular_reuse_assessment",
            "privacy_required": True,
            "required_tools": ["check_explicit_missingness"],
        },
        "agentic": {"required_tools": []},
    }

    result = determine_reuse_verdict(
        issues=[],
        executed_tools=["check_explicit_missingness"],
        config=config,
    )

    assert result["verdict"] == "INSUFFICIENT_EVIDENCE"
    assert result["minimum_required_tools"] == [
        "check_explicit_missingness",
        "check_metadata_completeness",
        "check_privacy_documentation",
    ]
    assert result["missing_required_tools"] == [
        "check_metadata_completeness",
        "check_privacy_documentation",
    ]
    assert result["decision_contract"]["configuration_cannot_weaken_minimum_evidence"] is True


def test_confirmed_missingness_prevents_ready_after_minimum_checks_complete():
    issue = Issue(
        issue_id="missing-1",
        issue_type="explicit_missingness",
        scope="cell",
        column="Age",
        row_index=1,
        value=None,
        evidence_status="confirmed",
        confidence=1.0,
        severity=0.2,
        evidence={"source": "pandas_isna"},
    )
    config = {
        "reuse_purpose": {
            "privacy_required": True,
            "required_tools": [],
        }
    }

    result = determine_reuse_verdict(
        issues=[issue],
        executed_tools=[
            "check_explicit_missingness",
            "check_metadata_completeness",
            "check_privacy_documentation",
        ],
        config=config,
    )

    assert result["verdict"] == "CONDITIONALLY_READY"
    assert result["confirmed_quality_issue_count"] == 1
