from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from cdqc_core.pipeline import run_assessment


def test_recommendations_are_grouped_not_repeated_per_cell(tmp_path: Path):
    df = pd.DataFrame({"Measurement": [-999] * 10 + list(range(20, 110))})
    input_path = tmp_path / "input.csv"
    config_path = tmp_path / "config.json"
    output = tmp_path / "out"
    df.to_csv(input_path, index=False)
    config_path.write_text(json.dumps({"columns": {"Measurement": {"role": "numeric", "description": "measurement"}}}), encoding="utf-8")
    run_assessment(input_path, output, config_path=config_path)
    recommendations = pd.read_csv(output / "recommendations.csv")
    sentinel_recommendations = recommendations[recommendations["issue_type"] == "disguised_missingness_candidate"]
    assert len(sentinel_recommendations) == 2
    assert set(sentinel_recommendations["affected_count"]) == {10}


def test_no_reference_metrics_do_not_claim_accuracy(tmp_path: Path):
    df = pd.DataFrame({"A": [1, 2, 3]})
    input_path = tmp_path / "input.csv"
    output = tmp_path / "out"
    df.to_csv(input_path, index=False)
    run_assessment(input_path, output)
    metrics = json.loads((output / "quality_support_metrics.json").read_text())
    assert "accuracy" not in metrics
    assert "confirmed_validity_support" in metrics
    assert metrics["metric_contract"]["confirmed_validity_support"].endswith("not ground-truth accuracy.")
