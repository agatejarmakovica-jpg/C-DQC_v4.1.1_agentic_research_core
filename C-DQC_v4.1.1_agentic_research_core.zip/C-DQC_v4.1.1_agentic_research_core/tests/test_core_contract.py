from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

from cdqc_core.detectors import detect_issues
from cdqc_core.inject import inject_benchmark_defects, make_synthetic_health_dataset
from cdqc_core.metrics import detection_metrics
from cdqc_core.pipeline import run_assessment


def test_injected_defects_have_exact_coordinates():
    clean, config = make_synthetic_health_dataset(rows=200, seed=101)
    corrupted, corrupted_config, truth = inject_benchmark_defects(clean, config, seed=1002)
    issues = detect_issues(corrupted, corrupted_config)
    metrics = detection_metrics(issues, truth.to_dict(orient="records"))
    assert metrics["recall"] >= 0.95
    assert metrics["precision"] >= 0.90
    assert metrics["f1"] >= 0.92


def test_date_diversity_without_target_is_column_scoped_only():
    df = pd.DataFrame({"Visit Date": ["2024-01-02", "03/04/2024", "2024-05-06"]})
    issues = detect_issues(df, {"columns": {"Visit Date": {"role": "date", "description": "date"}}})
    assert not any(issue.issue_type == "date_format_inconsistency" for issue in issues)
    diversity = [issue for issue in issues if issue.issue_type == "date_representation_diversity"]
    assert len(diversity) == 1
    assert diversity[0].scope == "column"
    assert diversity[0].row_index is None


def test_primary_output_preserves_schema(tmp_path: Path):
    df = pd.DataFrame({"A": [1, 2], "B": ["x", "y"]})
    input_path = tmp_path / "input.csv"
    output = tmp_path / "out"
    df.to_csv(input_path, index=False)
    run_assessment(input_path, output)
    snapshot = pd.read_csv(output / "input_snapshot.csv")
    assert list(snapshot.columns) == ["A", "B"]
    assert snapshot.equals(df)
    manifest = json.loads((output / "run_manifest.json").read_text())
    assert manifest["primary_output_contract"]["automatic_data_repair"] is False


def test_schema_gap_is_column_scoped():
    df = pd.DataFrame({"A": [1, 2, 3]})
    config = {"metadata_required_fields": ["role", "description"], "columns": {"A": {"role": "numeric"}}}
    issues = detect_issues(df, config)
    gaps = [issue for issue in issues if issue.issue_type == "schema_metadata_gap"]
    assert len(gaps) == 1
    assert gaps[0].scope == "column"
    assert gaps[0].row_index is None
